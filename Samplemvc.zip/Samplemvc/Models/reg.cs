﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Samplemvc.Models
{
    public class reg
    {
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student name")]
        public string name { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student address")]
        [DataType(DataType.MultilineText)]
        public string address { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student gender")]
        public string gender { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student email")]
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student course")]
        public course courselist { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student username")]
        public string username { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student pswd")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "student cpswd")]
        [Compare("password")]
        public string confirm_password { get; set; }

    }
    public enum course
    {
        BCA,
        BTECH,
        MCA,
        MTECH
    }
    
}