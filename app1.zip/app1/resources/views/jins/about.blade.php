@extends('layouts.app2')
@section('content')
<h1>About</h>
<p>This is my About page</p>
@endsection
