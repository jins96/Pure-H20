@extends('layouts.app2')
@section('content')
<h1>Services</h>
<p>This is my service page</p>
@endsection
