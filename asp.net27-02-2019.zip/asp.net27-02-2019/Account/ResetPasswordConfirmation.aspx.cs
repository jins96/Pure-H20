﻿using System.Web.UI;

namespace SampleApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}