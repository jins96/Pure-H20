<form method="post" action="<?php echo e(route('book.update',$books->id)); ?>">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <title></title>
  Title:
    <input type="text" name="title" value=<?php echo e($books->title); ?>><br><br>
    <body>
      Body:
      <input type="text" name="body" value=<?php echo e($books->body); ?>><br><br>
      <button type="submit" name="sub">UPDATE</button>
    </body>
  </form>
