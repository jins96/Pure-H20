<table border="1">
<thead>
<tr>
  <td>ID</td>
  <td>Rno</td>
  <td>Name</td>
  <td>class</td>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $studentdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($student->id); ?></td>
<td><?php echo e($student->rno); ?></td>
<td><?php echo e($student->name); ?></td>
<td><?php echo e($student->class); ?></td>
<td>
  <a href="<?php echo e(route('student.edit',$student->id)); ?>">Edit</a>
</td>
<td>
<form action="<?php echo e(route('student.destroy',$student->id)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('DELETE'); ?>
  <button type="submit">Delete</button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
