<form method="post" action="<?php echo e(route('student.update',$students->id)); ?>">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <title></title>
  rno:
    <input type="text" name="rno" value=<?php echo e($students->rno); ?>><br><br>
    <body>
      name:
      <input type="text" name="name" value=<?php echo e($students->name); ?>><br><br>
      class:
        <input type="text" name="class" value=<?php echo e($students->class); ?>><br><br>
      <button type="submit" name="sub">UPDATE</button>
    </body>
  </form>
