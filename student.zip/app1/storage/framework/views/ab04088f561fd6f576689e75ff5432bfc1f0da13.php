<?php $__env->startSection('content'); ?>
<h1>Services</h>
<p>This is my service page</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>