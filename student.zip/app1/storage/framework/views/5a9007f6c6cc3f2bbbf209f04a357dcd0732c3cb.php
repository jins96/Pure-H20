<?php $__env->startSection('content'); ?>
<h1>About</h>
<p>This is my About page</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>