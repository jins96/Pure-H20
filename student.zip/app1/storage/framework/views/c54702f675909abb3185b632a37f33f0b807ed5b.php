<?php $__env->startSection('content'); ?>
<h1>Index</h>
  <h2><?php echo e($name); ?></h2>

<p>This is my Index page</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>