<form method="post" action="{{route('student.store')}}">
  @csrf
  <title></title>
  Rno:
    <input type="text" name="rno"><br><br>
    <body>
      Name:
      <input type="text" name="name"><br><br>
      class:
      <input type="text" name="class"><br><br>
      <button type="submit" name="sub">ADD</button>
    </body>
  </form>
