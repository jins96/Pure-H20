<table border="1">
<thead>
<tr>
  <td>ID</td>
  <td>Rno</td>
  <td>Name</td>
  <td>class</td>
</tr>
</thead>
<tbody>
@foreach($studentdetails as $student)
<tr>
<td>{{$student->id}}</td>
<td>{{$student->rno}}</td>
<td>{{$student->name}}</td>
<td>{{$student->class}}</td>
<td>
  <a href="{{route('student.edit',$student->id)}}">Edit</a>
</td>
<td>
<form action="{{route('student.destroy',$student->id)}}" method="post">
  @csrf
  @method('DELETE')
  <button type="submit">Delete</button>
</form>
</td>
</tr>
@endforeach
</tbody>
</table>
