<form method="post" action="{{route('student.update',$students->id)}}">
  @method('PATCH')
  @csrf
  <title></title>
  rno:
    <input type="text" name="rno" value={{$students->rno}}><br><br>
    <body>
      name:
      <input type="text" name="name" value={{$students->name}}><br><br>
      class:
        <input type="text" name="class" value={{$students->class}}><br><br>
      <button type="submit" name="sub">UPDATE</button>
    </body>
  </form>
