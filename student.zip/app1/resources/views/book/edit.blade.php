<form method="post" action="{{route('book.update',$books->id)}}">
  @method('PATCH')
  @csrf
  <title></title>
  Title:
    <input type="text" name="title" value={{$books->title}}><br><br>
    <body>
      Body:
      <input type="text" name="body" value={{$books->body}}><br><br>
      <button type="submit" name="sub">UPDATE</button>
    </body>
  </form>
