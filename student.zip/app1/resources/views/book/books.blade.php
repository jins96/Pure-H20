<form method="post" action="{{route('book.store')}}">
  @csrf
  <title></title>
  Title:
    <input type="text" name="title"><br><br>
    <body>
      Body:
      <input type="text" name="body"><br><br>
      <button type="submit" name="sub">ADD</button>
    </body>
  </form>
  
