@extends('layouts.app2')
@section('content')
<h1>Index</h>
  <h2>{{$name}}</h2>

<p>This is my Index page</p>
@endsection
