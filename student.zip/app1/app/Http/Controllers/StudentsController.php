<?php

namespace App\Http\Controllers;

use App\students;
use Illuminate\Http\Request;

class StudentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $studentdetails=students::all();
      return view('student.index',compact('studentdetails'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
          return view('student.students');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $student=new students([
        'rno'=>$request->get('rno'),
        'name'=>$request->get('name'),
        'class'=>$request->get('class')
      ]);
      $student->save();
      return redirect('/student/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\students  $students
     * @return \Illuminate\Http\Response
     */
    public function show(students $students)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\students  $students
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $students=students::find($id);
      return view('student.edit',compact('students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\students  $students
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $student=students::find($id);
      $student->rno=$request->get('rno');
        $student->name=$request->get('name');
        $student->class=$request->get('class');
      $student->save();
      return redirect('/book');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\students  $students
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      $student=students::find($id);

      $student->delete();
      return redirect('/student')->with('sucess','book has been deleted successfully');
    }
}
