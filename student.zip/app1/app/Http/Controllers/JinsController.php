<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JinsController extends Controller
{
    public function about()
	{
		return view('jins.about');
	}
  public function service()
{
  return view('jins.service');
}
public function index()
{
  $title="jins";
  return view('jins.index')->with('name',$title);

}
}
