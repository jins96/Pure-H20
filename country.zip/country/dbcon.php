<?php
$con=mysqli_connect("localhost","root","","country1");

?>
